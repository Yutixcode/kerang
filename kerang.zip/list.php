<?php
$list = scandir(".");
$link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
echo $link;
?>